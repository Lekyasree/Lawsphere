const mongoose = require("mongoose");

const caseSchema = new mongoose.Schema({
  clientName: String,
  courtDetails: {
    courtName: String,
    branchName: String,
  },
  caseDetails: String,
  petitionerVsRespondent: String,
  status: String,
});

const Case = mongoose.model("Case", caseSchema);

module.exports = Case;
