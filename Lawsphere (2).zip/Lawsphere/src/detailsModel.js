const mongoose = require("./config"); // Import the shared MongoDB connection

const caseSchema = new Schema({
  clientName: String,
  courtDetails: {
    courtName: String,
    branchName: String,
  },
  caseDetails: String,
  petitionerVsRespondent: String,
  status: String,
  hearings: [{
    date: Date,
    notes: String,
  }],
});

module.exports = mongoose.model('Case', caseSchema);
