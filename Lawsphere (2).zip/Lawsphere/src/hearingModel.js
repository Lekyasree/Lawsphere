const mongoose = require("./config"); // Import the shared MongoDB connection

const hearingSchema = new mongoose.Schema({
    caseId: { type: String, required: true },
    petitioner: { type: String, required: true },
    respondent: { type: String, required: true },
    courtName: { type: String, required: true },
    caseType: { type: String, required: true },
    caseTitle: { type: String, required: true },
    hearingDate: { type: Date, required: true },
    petitionerAddress: { type: String, required: true },
    respondentAddress: { type: String, required: true }
});

const Hearing = mongoose.model('Hearing', hearingSchema);

module.exports = Hearing;
