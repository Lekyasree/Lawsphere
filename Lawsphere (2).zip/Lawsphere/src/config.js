// config.js
const mongoose = require("mongoose");

const connectionString = "mongodb://localhost:27017/lawsphere"; // Common connection string

mongoose
  .connect(connectionString, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log("Database connected successfully.");
  })
  .catch((err) => {
    console.error("Database connection error:", err);
  });

module.exports = mongoose; // Export the connected mongoose instance
