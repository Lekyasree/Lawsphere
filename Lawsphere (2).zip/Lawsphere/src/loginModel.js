// loginModel.js
const mongoose = require("./config"); // Import the shared MongoDB connection
const bcrypt = require("bcrypt");

const loginSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  password: {
    type: String,
    required: true,
  },
});

const LoginCollection = mongoose.model("users", loginSchema);

module.exports = LoginCollection;
