let slides = document.querySelector('.slides');
let items = document.querySelectorAll('.slides .item');

let active = 0;

function prevSlide() {
    if (active === 0) {
        active = items.length - 1;
    } else {
        active--;
    }
    updateSlider();
}

function nextSlide() {
    if (active === items.length - 1) {
        active = 0;
    } else {
        active++;
    }
    updateSlider();
}

function updateSlider() {
    slides.style.transform = `translateX(-${active * 100}%)`;
}
