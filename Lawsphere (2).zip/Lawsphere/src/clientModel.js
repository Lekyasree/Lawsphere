// clientModel.js
const mongoose = require("./config"); // Import the shared MongoDB connection

const clientSchema = new mongoose.Schema({
  first_name: String,
  middle_name: String,
  last_name: String,
  gender: String,
  email: String,
  mobile_no: String,
  alternate_no: String,
  address: String,
  country: String,
  state: String,
  city: String,
});

const ClientCollection = mongoose.model("Client", clientSchema);

module.exports = ClientCollection;
