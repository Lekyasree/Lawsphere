const express = require("express");
const path = require("path");
const bodyParser = require("body-parser");
const mongoose = require("./config"); // Import the configured mongoose instance
const Case = require("./caseModel"); // Import the Case model
const bcrypt = require("bcrypt"); // Ensure bcrypt is required for hashing passwords
const Hearing = require('./hearingModel'); // Import your Hearing model

const app = express();

// Middleware
app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "ejs");
app.use(express.static("public"));

// Middleware to log requests
app.use((req, res, next) => {
  console.log(`${req.method} ${req.url}`);
  next();
});

// Initialize clients array
let clients = [];

// MongoDB connection is already handled in the config file

// Home page
app.get("/", (req, res) => {
  res.render("home");
});

// About page
app.get("/about", (req, res) => {
  res.render("about");
});

// Case page
app.get("/case", async (req, res) => {
  try {
    const cases = await Case.find();
    res.render("case", { cases });
  } catch (error) {
    console.error("Error fetching cases:", error);
    res.render("case", { cases: [] });
  }
});

// Add Case page
app.get("/addCase", (req, res) => {
  res.render("addCase");
});

// Submit case data
app.post("/submit-case", async (req, res) => {
  const { petitionerName, respondentName, courtName, branchName, caseType } = req.body;

  try {
    await Case.create({
      clientName: petitionerName, // Assuming petitionerName is the client name
      courtDetails: { courtName, branchName },
      caseDetails: caseType,
      petitionerVsRespondent: `${petitionerName} vs ${respondentName}`,
      status: "Pending", // Default status
    });
    res.redirect("/case");
  } catch (error) {
    console.error("Error adding case:", error);
    res.send("Error adding case");
  }
});

// Client listing page
app.get('/client', (req, res) => {
  res.render('client', { clients });
});

// Add Client page
app.get('/addClient', (req, res) => {
  res.render('addClient');
});

// Submit client data
app.post('/submit_client', (req, res) => {
  const client = {
    _id: clients.length + 1, // Use a better unique identifier in a real app
    firstName: req.body.first_name,
    lastName: req.body.last_name,
    mobileNo: req.body.mobile_no,
    caseType: req.body.case_type,
  };
  clients.push(client);
  res.redirect('/client'); // Redirect to client page after successful addition
});

// Edit Client page
app.get('/editClient/:id', (req, res) => {
  const client = clients.find(c => c._id === parseInt(req.params.id));
  res.render('editClient', { client });
});

// Update client data
app.post('/editClient/:id', (req, res) => {
  const clientIndex = clients.findIndex(c => c._id === parseInt(req.params.id));
  if (clientIndex !== -1) {
    clients[clientIndex] = { ...clients[clientIndex], ...req.body };
  }
  res.redirect('/client');
});

// Delete client
app.delete('/deleteClient/:id', (req, res) => {
  clients = clients.filter(client => client._id !== parseInt(req.params.id));
  res.status(200).send('Client deleted successfully');
});

// Edit Case page
app.get('/editCase/:id', async (req, res) => {
  try {
    const caseItem = await Case.findById(req.params.id);
    if (!caseItem) {
      return res.status(404).send('Case not found');
    }
    res.render('editCase', { caseItem });
  } catch (error) {
    console.error("Error fetching case:", error);
    res.status(500).send('Server error');
  }
});

// Update Case data
app.post('/editCase/:id', async (req, res) => {
  const { petitionerName, respondentName, courtName, branchName, caseType, status } = req.body;
  
  try {
    const caseItem = await Case.findById(req.params.id);
    if (!caseItem) {
      return res.status(404).send('Case not found');
    }
    caseItem.clientName = petitionerName;
    caseItem.courtDetails = { courtName, branchName };
    caseItem.caseDetails = caseType;
    caseItem.petitionerVsRespondent = `${petitionerName} vs ${respondentName}`;
    caseItem.status = status;
    
    await caseItem.save();
    res.redirect('/case');
  } catch (error) {
    console.error("Error updating case:", error);
    res.status(500).send('Server error');
  }
});

app.get('/details', (req, res) => {
  // Fetch case details as needed
  res.render('details');
});

app.get('/hearingDetails', (req, res) => {
  res.render('hearingDetails', );
});

// Submit hearing details and redirect back to details page
app.post('/submitHearing', async (req, res) => {
  try {
    // Extract data from request body
    const { caseId, petitioner, respondent, courtName, caseType, caseTitle, hearingDate, petitionerAddress, respondentAddress } = req.body;

    // Create a new hearing object
    const hearing = new Hearing({
      caseId,
      petitioner,
      respondent,
      courtName,
      caseType,
      caseTitle,
      hearingDate,
      petitionerAddress,
      respondentAddress
    });

    // Save the hearing details to the database
    await hearing.save();

    // Redirect back to the details page
    res.redirect('/details');
  } catch (error) {
    // Respond with error message
    console.error('Error saving hearing details:', error);
    res.status(500).send('Error saving hearing details. Please try again later.');
  }
});

// Case page
app.get("/case", async (req, res) => {
  try {
    const cases = await Case.find();
    res.render("case", { cases });
  } catch (error) {
    console.error("Error fetching cases:", error);
    res.render("case", { cases: [] });
  }
});

// Details page
app.get('/details', async (req, res) => {
  try {
    const cases = await Case.find(); // Fetch case details from the database
    res.render('details', { cases }); // Pass case details to the template
  } catch (error) {
    console.error("Error fetching case details:", error);
    res.status(500).send('Server error');
  }
});




// Login page
app.get('/login', (req, res) => {
  res.render('login');
});

// Signup page
app.get('/signup', (req, res) => {
  res.render('signup');
});

// Dummy user data for login/signup
let users = [];

// Handle user signup
app.post('/signup', async (req, res) => {
  const { username, password } = req.body;

  const existingUser = users.find(user => user.username === username);
  if (existingUser) {
    return res.send('User already exists. Please choose a different username.');
  }

  const hashedPassword = await bcrypt.hash(password, 10);
  users.push({ username, password: hashedPassword });

  res.render('home');
});

// Handle user login
app.post('/login', async (req, res) => {
  const { username, password } = req.body;

  const user = users.find(user => user.username === username);
  if (!user) {
    return res.send('Username not found.');
  }

  const isPasswordMatch = await bcrypt.compare(password, user.password);
  if (isPasswordMatch) {
    res.render('home');
  } else {
    res.send('Incorrect password.');
  }
});

// Start server
const port = 5000;
app.listen(port, () => {
  console.log(`Server running on port ${port}.`);
});
